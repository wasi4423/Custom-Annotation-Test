import java.lang.reflect.Field;
import java.util.*;

public class Container {
    private final Map<String, Object> beans = new LinkedHashMap<>();

    public void scan(Class<?>... classes) {
        for (Class<?> c : classes) {
            if (!c.isAnnotationPresent(Component.class)) {
                System.out.println("[Container] Skipped: " + c.getSimpleName() + " (no @Component)");
                continue;
            }
            try {
                Object obj = c.getDeclaredConstructor().newInstance();
                String name = c.getAnnotation(Component.class).value();
                if (name.isEmpty()) {
                    String s = c.getSimpleName();
                    name = Character.toLowerCase(s.charAt(0)) + s.substring(1);
                }
                beans.put(name, obj);
                System.out.println("[Container] Registered: " + name + " (" + c.getSimpleName() + ")");
            } catch (ReflectiveOperationException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void injectValues(Map<String, String> config) {
        for (Object bean : beans.values()) {
            for (Field f : bean.getClass().getDeclaredFields()) {
                Value v = f.getAnnotation(Value.class);
                if (v == null) continue;
                String raw = config.get(v.value());
                if (raw == null) continue;
                try {
                    f.setAccessible(true);
                    if (f.getType() == int.class || f.getType() == Integer.class)
                        f.set(bean, Integer.parseInt(raw));
                    else
                        f.set(bean, raw);
                    System.out.println("[Container] Injected: " + v.value() + " -> "
                            + bean.getClass().getSimpleName() + "." + f.getName());
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public Object getBean(String name) {
        return beans.get(name);
    }

    public Collection<Object> getBeans() {
        return beans.values();
    }
}
